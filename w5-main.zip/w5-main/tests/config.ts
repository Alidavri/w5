const config: any = {
    // Inspect per-instruction execution in primary (contest) test cases
    microscope: false
}

export default config;
